module.exports = {
    MONGOURI :'mongodb+srv://Nikhilpunse:7eZKaRdDRGAZa5bR@cluster0.qxgmq5w.mongodb.net/?retryWrites=true&w=majority',
    SECRET_KEY : 'it can be anything'
}

